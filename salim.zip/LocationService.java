package com.raksha.emergency;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.location.Location;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;

/**
 * RAKSHA — LocationService.java
 * Foreground service that:
 *   • Keeps the 5G data link alive via a persistent notification.
 *   • Polls the rescuer's GPS at 3-second intervals.
 *   • Broadcasts updates to RedAlertActivity via LocalBroadcast.
 *   • Computes Haversine distance to the target (victim).
 * Target: Android 13+ (API 33)
 */
public class LocationService extends Service {

    private static final String TAG            = "RAKSHA_LocationService";
    public  static final String CHANNEL_ID     = "raksha_alert_channel";
    public  static final String ACTION_UPDATE  = "com.raksha.emergency.LOCATION_UPDATE";
    public  static final String EXTRA_DISTANCE = "distance_km";
    public  static final String EXTRA_MY_LAT   = "my_lat";
    public  static final String EXTRA_MY_LON   = "my_lon";

    private FusedLocationProviderClient fusedClient;
    private LocationCallback locationCallback;

    private double targetLat = 0.0;
    private double targetLon = 0.0;

    // ── Service lifecycle ─────────────────────────────────────────────────────

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        fusedClient = LocationServices.getFusedLocationProviderClient(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            targetLat = intent.getDoubleExtra("target_lat", 0.0);
            targetLon = intent.getDoubleExtra("target_lon", 0.0);
            Log.d(TAG, "Target coords: " + targetLat + ", " + targetLon);
        }

        startForeground(1, buildNotification());
        startLocationUpdates();

        return START_STICKY; // Restart automatically if killed
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopLocationUpdates();
        Log.d(TAG, "LocationService destroyed.");
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null; // Not a bound service
    }

    // ── Location polling ──────────────────────────────────────────────────────

    private void startLocationUpdates() {
        LocationRequest request = new LocationRequest.Builder(
                Priority.PRIORITY_HIGH_ACCURACY, 3000L)  // 3-second interval
                .setMinUpdateIntervalMillis(1500L)
                .setWaitForAccurateLocation(false)
                .build();

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult result) {
                if (result == null) return;
                Location myLoc = result.getLastLocation();
                if (myLoc == null) return;

                double myLat = myLoc.getLatitude();
                double myLon = myLoc.getLongitude();
                double distKm = haversine(myLat, myLon, targetLat, targetLon);

                Log.d(TAG, String.format("My pos: %.5f, %.5f | Distance: %.2f km",
                        myLat, myLon, distKm));

                // Broadcast to RedAlertActivity
                Intent broadcast = new Intent(ACTION_UPDATE);
                broadcast.putExtra(EXTRA_MY_LAT,   myLat);
                broadcast.putExtra(EXTRA_MY_LON,   myLon);
                broadcast.putExtra(EXTRA_DISTANCE, distKm);
                sendBroadcast(broadcast);

                // Update notification distance
                NotificationManager nm =
                    (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                if (nm != null) nm.notify(1, buildNotification(distKm));
            }
        };

        try {
            fusedClient.requestLocationUpdates(request, locationCallback, Looper.getMainLooper());
        } catch (SecurityException e) {
            Log.e(TAG, "Location permission not granted: " + e.getMessage());
        }
    }

    private void stopLocationUpdates() {
        if (fusedClient != null && locationCallback != null) {
            fusedClient.removeLocationUpdates(locationCallback);
        }
    }

    // ── Haversine Formula ─────────────────────────────────────────────────────

    /**
     * Calculates the great-circle distance between two GPS coordinates.
     * @return distance in kilometres
     */
    public static double haversine(double lat1, double lon1, double lat2, double lon2) {
        final double R = 6371.0; // Earth radius in km
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                 + Math.cos(Math.toRadians(lat1))
                 * Math.cos(Math.toRadians(lat2))
                 * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "RAKSHA Emergency Alert",
                NotificationManager.IMPORTANCE_HIGH
        );
        channel.setDescription("Live tracking active for SOS emergency.");
        channel.enableVibration(false);
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.createNotificationChannel(channel);
    }

    private Notification buildNotification() {
        return buildNotification(-1);
    }

    private Notification buildNotification(double distKm) {
        Intent tapIntent = new Intent(this, RedAlertActivity.class);
        tapIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, tapIntent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );

        String contentText = distKm >= 0
                ? String.format("Distance to victim: %.2f km — Tracking live", distKm)
                : "RAKSHA tracking active. Waiting for GPS...";

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("🚨 RAKSHA SOS ACTIVE")
                .setContentText(contentText)
                .setSmallIcon(R.drawable.ic_sos)          // Add ic_sos.xml to res/drawable
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setContentIntent(pi)
                .build();
    }
}
