package com.raksha.emergency;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

/**
 * RAKSHA — RedAlertActivity.java
 * Full-screen Red Alert overlay. Shows over lock screen.
 * Plays looping emergency voice alert. Live tracking map.
 * Target: Android 13+ (API 33)
 */
public class RedAlertActivity extends AppCompatActivity implements OnMapReadyCallback {

    private static final String TAG = "RAKSHA_RedAlert";

    private GoogleMap   gMap;
    private Marker      targetMarker;
    private Marker      rescuerMarker;
    private MediaPlayer mediaPlayer;
    private TextView    tvDistance;
    private TextView    tvBlink;
    private Handler     blinkHandler = new Handler(Looper.getMainLooper());

    private double targetLat = 0.0;
    private double targetLon = 0.0;

    // ── BroadcastReceiver for live GPS updates from LocationService ───────────
    private final BroadcastReceiver locationReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context ctx, Intent intent) {
            double myLat    = intent.getDoubleExtra(LocationService.EXTRA_MY_LAT, 0);
            double myLon    = intent.getDoubleExtra(LocationService.EXTRA_MY_LON, 0);
            double distKm   = intent.getDoubleExtra(LocationService.EXTRA_DISTANCE, 0);

            updateMap(myLat, myLon, distKm);
        }
    };

    // ── Activity lifecycle ────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ── Show over lock screen flags (API 27+ compatible) ──────────────
        getWindow().addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON        |
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD      |
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED      |
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        );
        setShowWhenLocked(true);     // API 27+
        setTurnScreenOn(true);       // API 27+

        setContentView(R.layout.activity_red_alert);

        // Hide system UI for full immersive mode
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );

        // Get target coords from intent
        targetLat = getIntent().getDoubleExtra("target_lat", 0.0);
        targetLon = getIntent().getDoubleExtra("target_lon", 0.0);

        tvDistance = findViewById(R.id.tv_distance);
        tvBlink    = findViewById(R.id.tv_blink_sos);

        // Init map
        SupportMapFragment mapFrag = (SupportMapFragment)
            getSupportFragmentManager().findFragmentById(R.id.map_fragment);
        if (mapFrag != null) mapFrag.getMapAsync(this);

        // Start audio
        startEmergencyAudio();

        // Start blinking SOS text
        startBlinkAnimation();

        // Register location update receiver
        IntentFilter filter = new IntentFilter(LocationService.ACTION_UPDATE);
        registerReceiver(locationReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopEmergencyAudio();
        blinkHandler.removeCallbacksAndMessages(null);
        unregisterReceiver(locationReceiver);
    }

    // ── Google Maps ───────────────────────────────────────────────────────────

    @Override
    public void onMapReady(GoogleMap map) {
        gMap = map;
        gMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        gMap.getUiSettings().setAllGesturesEnabled(true);

        LatLng target = new LatLng(targetLat, targetLon);
        targetMarker = gMap.addMarker(new MarkerOptions()
                .position(target)
                .title("Needs Help")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
        gMap.moveCamera(CameraUpdateFactory.newLatLngZoom(target, 15f));
    }

    // ── Map update (called from BroadcastReceiver) ────────────────────────────

    private void updateMap(double myLat, double myLon, double distKm) {
        if (gMap == null) return;

        LatLng myPos = new LatLng(myLat, myLon);

        if (rescuerMarker == null) {
            rescuerMarker = gMap.addMarker(new MarkerOptions()
                    .position(myPos)
                    .title("You (Rescuer)")
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)));
        } else {
            rescuerMarker.setPosition(myPos);
        }

        // Auto-zoom to show both markers
        LatLngBounds bounds = new LatLngBounds.Builder()
                .include(new LatLng(targetLat, targetLon))
                .include(myPos)
                .build();
        gMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, 120));

        // Update distance label
        String label = distKm < 1.0
                ? String.format("Distance: %d m", (int)(distKm * 1000))
                : String.format("Distance: %.2f km", distKm);
        tvDistance.setText(label);
    }

    // ── Audio ─────────────────────────────────────────────────────────────────

    /**
     * Plays emergency_voice_alert.mp3 (place in res/raw/) on a loop at max volume.
     */
    private void startEmergencyAudio() {
        try {
            mediaPlayer = MediaPlayer.create(this, R.raw.emergency_voice_alert);
            if (mediaPlayer == null) return;

            mediaPlayer.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build());
            mediaPlayer.setLooping(true);
            mediaPlayer.setVolume(1.0f, 1.0f);
            mediaPlayer.start();
        } catch (Exception e) {
            // Fallback: use TTS or default alarm tone
        }
    }

    private void stopEmergencyAudio() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    // ── Blink animation ───────────────────────────────────────────────────────

    private boolean blinkVisible = true;

    private void startBlinkAnimation() {
        Runnable blinkRunnable = new Runnable() {
            @Override public void run() {
                tvBlink.setVisibility(blinkVisible ? View.VISIBLE : View.INVISIBLE);
                blinkVisible = !blinkVisible;
                blinkHandler.postDelayed(this, 500);
            }
        };
        blinkHandler.post(blinkRunnable);
    }

    // ── Dismiss button ────────────────────────────────────────────────────────

    public void onDismissClicked(View v) {
        // Stop the foreground service and finish
        stopService(new Intent(this, LocationService.class));
        stopEmergencyAudio();
        finish();
    }
}
