package com.raksha.emergency;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.tasks.CancellationTokenSource;

import java.util.Arrays;
import java.util.List;

/**
 * RAKSHA — SenderActivity.java
 * The victim's phone: large SOS button captures GPS and
 * fires ACTIVATE_RED_ALERT_SOS_<lat>_<lon> to all 10 contacts.
 */
public class SenderActivity extends AppCompatActivity {

    private static final String TAG = "RAKSHA_Sender";

    // The 10 emergency contacts (E.164 format)
    private static final List<String> EMERGENCY_CONTACTS = Arrays.asList(
            "+917010733249",
            "+919787400163",
            "+919344007335"
            // ... add up to 10 numbers
    );

    private FusedLocationProviderClient fusedClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sender);
        fusedClient = LocationServices.getFusedLocationProviderClient(this);

        // Request permissions
        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.SEND_SMS,
                Manifest.permission.RECEIVE_SMS
        }, 100);
    }

    /**
     * Called by the big SOS button (android:onClick="onSosPressed" in XML).
     */
    public void onSosPressed(View v) {
        Toast.makeText(this, "Fetching GPS — hold on...", Toast.LENGTH_SHORT).show();
        fetchGpsAndBroadcast();
    }

    private void fetchGpsAndBroadcast() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Location permission required!", Toast.LENGTH_LONG).show();
            return;
        }

        // High-accuracy single shot (works great on 5G)
        CancellationTokenSource cts = new CancellationTokenSource();
        fusedClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.getToken())
                .addOnSuccessListener(location -> {
                    if (location != null) {
                        broadcastSos(location);
                    } else {
                        Toast.makeText(this, "Could not get GPS. Try again.", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "GPS fetch failed: " + e.getMessage());
                    Toast.makeText(this, "GPS error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    /**
     * Sends the secret SOS command to all emergency contacts via SMS.
     * Format: ACTIVATE_RED_ALERT_SOS_<lat>_<lon>
     */
    private void broadcastSos(Location loc) {
        double lat = loc.getLatitude();
        double lon = loc.getLongitude();
        String command = "ACTIVATE_RED_ALERT_SOS_" + lat + "_" + lon;

        Log.d(TAG, "Broadcasting SOS: " + command);

        SmsManager smsManager = SmsManager.getDefault();
        int sentCount = 0;

        for (String number : EMERGENCY_CONTACTS) {
            try {
                smsManager.sendTextMessage(number, null, command, null, null);
                sentCount++;
                Log.d(TAG, "SOS sent to " + number);
            } catch (Exception e) {
                Log.e(TAG, "Failed to send SMS to " + number + ": " + e.getMessage());
            }
        }

        Toast.makeText(this,
                "SOS sent to " + sentCount + " contacts!\nLat: " + lat + " Lon: " + lon,
                Toast.LENGTH_LONG).show();
    }
}
