package com.raksha.emergency;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.util.Log;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * RAKSHA — SmsReceiver.java
 * Listens for the secret SOS command SMS from whitelisted contacts.
 * Triggers Red Alert UI and overrides DND/Silent mode.
 * Target: Android 13+ (API 33)
 */
public class SmsReceiver extends BroadcastReceiver {

    private static final String TAG = "RAKSHA_SmsReceiver";

    // Secret command prefix — must match exactly what SenderActivity broadcasts
    private static final String SOS_COMMAND_PREFIX = "ACTIVATE_RED_ALERT_SOS_";

    // ── Whitelisted sender numbers (E.164 format) ──────────────────────────
    private static final Set<String> WHITELIST = new HashSet<>(Arrays.asList(
            "+917010733249",
            "+919787400163",
            "+919344007335"
            // Add up to 10 numbers here
    ));

    @Override
    public void onReceive(Context context, Intent intent) {

        if (!Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) return;

        Bundle bundle = intent.getExtras();
        if (bundle == null) return;

        Object[] pdus = (Object[]) bundle.get("pdus");
        String format  = bundle.getString("format");
        if (pdus == null) return;

        for (Object pdu : pdus) {
            SmsMessage msg = SmsMessage.createFromPdu((byte[]) pdu, format);
            if (msg == null) continue;

            String sender  = normalizeNumber(msg.getOriginatingAddress());
            String body    = msg.getMessageBody();

            Log.d(TAG, "SMS from: " + sender + " | body prefix: " +
                    (body != null ? body.substring(0, Math.min(30, body.length())) : "null"));

            // Security gate: only react to whitelisted senders
            if (!WHITELIST.contains(sender)) {
                Log.d(TAG, "Sender not in whitelist — ignored.");
                continue;
            }

            // Parse command: ACTIVATE_RED_ALERT_SOS_<lat>_<lon>
            if (body != null && body.startsWith(SOS_COMMAND_PREFIX)) {
                String payload = body.substring(SOS_COMMAND_PREFIX.length()); // "<lat>_<lon>"
                String[] parts = payload.split("_");

                double lat = 0.0, lon = 0.0;
                try {
                    lat = Double.parseDouble(parts[0]);
                    lon = Double.parseDouble(parts[1]);
                } catch (Exception e) {
                    Log.e(TAG, "Could not parse GPS from payload: " + payload);
                }

                Log.d(TAG, "SOS activated! Lat=" + lat + " Lon=" + lon);

                // 1. Override Silent/DND — set volume to max
                forceMaxVolume(context);

                // 2. Trigger vibration pulse
                triggerVibration(context);

                // 3. Launch Red Alert full-screen activity
                launchRedAlert(context, sender, lat, lon);

                // 4. Start foreground service to keep tracking alive
                Intent serviceIntent = new Intent(context, LocationService.class);
                serviceIntent.putExtra("target_lat", lat);
                serviceIntent.putExtra("target_lon", lon);
                serviceIntent.putExtra("sender", sender);
                context.startForegroundService(serviceIntent);

                break; // One alert is enough per batch of PDUs
            }
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    /**
     * Normalizes phone numbers to E.164 (+91XXXXXXXXXX) for consistent matching.
     */
    private String normalizeNumber(String raw) {
        if (raw == null) return "";
        // Remove spaces, dashes, brackets
        String clean = raw.replaceAll("[\\s\\-().]", "");
        // Indian numbers: if 10 digits, prepend +91
        if (clean.matches("\\d{10}")) return "+91" + clean;
        // If already has country code without +
        if (clean.matches("91\\d{10}")) return "+" + clean;
        return clean;
    }

    /**
     * Forces all audio streams to maximum volume, overriding DND and Silent.
     * Requires MODIFY_AUDIO_SETTINGS permission in AndroidManifest.
     */
    private void forceMaxVolume(Context ctx) {
        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            if (am == null) return;

            // Override DND / Silent mode
            am.setRingerMode(AudioManager.RINGER_MODE_NORMAL);

            int[] streams = {
                AudioManager.STREAM_RING,
                AudioManager.STREAM_ALARM,
                AudioManager.STREAM_MUSIC,
                AudioManager.STREAM_NOTIFICATION
            };
            for (int stream : streams) {
                int max = am.getStreamMaxVolume(stream);
                am.setStreamVolume(stream, max, AudioManager.FLAG_SHOW_UI);
            }
            Log.d(TAG, "Volume forced to max on all streams.");
        } catch (Exception e) {
            Log.e(TAG, "forceMaxVolume failed: " + e.getMessage());
        }
    }

    /**
     * Pulses the vibrator in SOS pattern (··· — — — ···).
     */
    private void triggerVibration(Context ctx) {
        try {
            Vibrator v = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null || !v.hasVibrator()) return;

            // SOS pattern: dot=200ms, dash=600ms, gap=200ms, pause=800ms
            long[] pattern = {
                0, 200, 200, 200, 200, 200, 200,   // · · ·
                400, 600, 200, 600, 200, 600, 400,  // — — —
                0, 200, 200, 200, 200, 200           // · · ·
            };
            VibrationEffect effect = VibrationEffect.createWaveform(pattern, 0); // 0 = repeat
            v.vibrate(effect);
        } catch (Exception e) {
            Log.e(TAG, "triggerVibration failed: " + e.getMessage());
        }
    }

    /**
     * Starts the full-screen Red Alert activity over the lock screen.
     */
    private void launchRedAlert(Context ctx, String sender, double lat, double lon) {
        Intent alertIntent = new Intent(ctx, RedAlertActivity.class);
        alertIntent.putExtra("target_lat", lat);
        alertIntent.putExtra("target_lon", lon);
        alertIntent.putExtra("sender_number", sender);
        alertIntent.addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK |
            Intent.FLAG_ACTIVITY_CLEAR_TOP |
            Intent.FLAG_ACTIVITY_SINGLE_TOP |
            Intent.FLAG_FROM_BACKGROUND
        );
        ctx.startActivity(alertIntent);
        Log.d(TAG, "RedAlertActivity launched.");
    }
}
